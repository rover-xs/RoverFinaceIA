import { createClient } from '@supabase/supabase-js';

const SURL = "https://exvjdtmpwfhcpzgglhms.supabase.co";
const SKEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV4dmpkdG1wd2ZoY3B6Z2dsaG1zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQwMjAxMjAsImV4cCI6MjA3OTU5NjEyMH0.q78TvUlXqTTzpHcYsgFqb4WMJRq7E238FEfcJ92slzg";

export const supabase = createClient(SURL, SKEY);
