import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

// Adicionar tipagem para o plugin autoTable do jsPDF herdando de jsPDF
interface jsPDFWithPlugin extends jsPDF {
  autoTable: (options: any) => any;
  lastAutoTable: {
    finalY: number;
  };
}

export function exportFinancialPDF(data: {
  income: any[];
  fixed: any[];
  inst: any[];
  daily: any[];
  goals: any[];
  summary: {
    totalIncome: number;
    totalExpenses: number;
    totalFixed: number;
    totalInstallments: number;
    totalDaily: number;
    totalDebt: number;
    balance: number;
  }
}) {
  const doc = new jsPDF('p', 'mm', 'a4') as any;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  let yPos = 15;

  const fmt = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);

  // Cabeçalho Premium
  doc.setFillColor(10, 15, 30); // Dark Blue Navy do tema
  doc.rect(0, 0, pageWidth, 28, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('ROVER FINANCE', 14, 18);
  
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text(`Relatório Financeiro Consolidado · Gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}`, 14, 24);
  
  yPos = 38;

  // Título do Resumo
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text('1. RESUMO EXECUTIVO DO MÊS', 14, yPos);
  yPos += 6;

  // Tabela de Resumo Executivo
  doc.autoTable({
    startY: yPos,
    head: [['Indicador Financeiro', 'Valor']],
    body: [
      ['Receitas Totais (+)', fmt(data.summary.totalIncome)],
      ['Despesas Totais (-)', fmt(data.summary.totalExpenses)],
      ['  · Despesas Fixas', fmt(data.summary.totalFixed)],
      ['  · Parcelas Ativas', fmt(data.summary.totalInstallments)],
      ['  · Gastos À Vista', fmt(data.summary.totalDaily)],
      ['Dívida Total Restante (Futura)', fmt(data.summary.totalDebt)],
      ['SALDO ATUAL', fmt(data.summary.balance)]
    ],
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
    bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    columnStyles: { 0: { cellWidth: 115 }, 1: { halign: 'right', cellWidth: 45, fontStyle: 'bold' } },
    margin: { left: 14, right: 14 },
    didParseCell: function(dataCell: any) {
      if (dataCell.section === 'body' && dataCell.row.index === 6) {
        // Estilizar a linha do saldo
        dataCell.cell.styles.fontStyle = 'bold';
        if (data.summary.balance >= 0) {
          dataCell.cell.styles.textColor = [16, 185, 129]; // Verde
        } else {
          dataCell.cell.styles.textColor = [239, 68, 68]; // Vermelho
        }
      }
    }
  });
  
  yPos = doc.lastAutoTable.finalY + 12;

  // Gastos por Categoria
  const cm: { [key: string]: number } = {};
  [...data.daily, ...data.fixed, ...data.inst].forEach(x => {
    const c = x.category || 'Outros';
    cm[c] = (cm[c] || 0) + Number(x.value || 0);
  });
  const catBody = Object.entries(cm)
    .sort((a, b) => b[1] - a[1])
    .map(([cat, val]) => [cat, fmt(val), `${((val / (data.summary.totalExpenses || 1)) * 100).toFixed(1)}%`]);

  if (catBody.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('2. DISTRIBUIÇÃO POR CATEGORIA', 14, yPos);
    yPos += 6;

    doc.autoTable({
      startY: yPos,
      head: [['Categoria', 'Total Consumido', 'Representação']],
      body: catBody,
      theme: 'grid',
      headStyles: { fillColor: [59, 130, 246], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 0: { cellWidth: 85 }, 1: { halign: 'right', cellWidth: 40 }, 2: { halign: 'right', cellWidth: 35 } },
      margin: { left: 14, right: 14 }
    });
    yPos = doc.lastAutoTable.finalY + 12;
  }

  // Seção de Receitas
  if (data.income.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('3. DETALHAMENTO DE RECEITAS', 14, yPos);
    yPos += 6;

    const incBody = data.income.map(i => [i.source || 'Sem descrição', fmt(i.value)]);
    doc.autoTable({
      startY: yPos,
      head: [['Fonte de Renda', 'Valor']],
      body: incBody,
      theme: 'grid',
      headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 0: { cellWidth: 115 }, 1: { halign: 'right', cellWidth: 45 } },
      margin: { left: 14, right: 14 }
    });
    yPos = doc.lastAutoTable.finalY + 12;
  }

  // Seção de Despesas Fixas
  if (data.fixed.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('4. COMPROMISSOS MENSAIS (DESPESAS FIXAS)', 14, yPos);
    yPos += 6;

    const fixBody = data.fixed.map(f => [f.name || 'Sem descrição', f.category || 'Outros', fmt(f.value)]);
    doc.autoTable({
      startY: yPos,
      head: [['Descrição', 'Categoria', 'Valor']],
      body: fixBody,
      theme: 'grid',
      headStyles: { fillColor: [59, 130, 246], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 0: { cellWidth: 80 }, 1: { cellWidth: 45 }, 2: { halign: 'right', cellWidth: 35 } },
      margin: { left: 14, right: 14 }
    });
    yPos = doc.lastAutoTable.finalY + 12;
  }

  // Seção de Parcelamentos
  if (data.inst.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('5. COMPRAS PARCELADAS ATIVAS', 14, yPos);
    yPos += 6;

    const instBody = data.inst.map(i => [
      i.name || 'Sem descrição',
      i.category || 'Outros',
      `${i.paid}/${i.total}`,
      fmt(i.value),
      fmt(Number(i.value) * Math.max(Number(i.total) - Number(i.paid), 0))
    ]);
    doc.autoTable({
      startY: yPos,
      head: [['Item / Estabelecimento', 'Categoria', 'Progresso', 'Valor Parcela', 'Saldo Restante']],
      body: instBody,
      theme: 'grid',
      headStyles: { fillColor: [139, 92, 246], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 
        0: { cellWidth: 55 }, 
        1: { cellWidth: 30 }, 
        2: { halign: 'center', cellWidth: 20 }, 
        3: { halign: 'right', cellWidth: 25 }, 
        4: { halign: 'right', cellWidth: 30 } 
      },
      margin: { left: 14, right: 14 }
    });
    yPos = doc.lastAutoTable.finalY + 12;
  }

  // Seção de Gastos À Vista
  if (data.daily.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('6. HISTÓRICO DE GASTOS À VISTA (ÚLTIMOS 30)', 14, yPos);
    yPos += 6;

    const dailyBody = data.daily.slice(-30).map(d => [
      d.date ? new Date(d.date + 'T00:00:00').toLocaleDateString('pt-BR') : 'Sem data',
      d.description || 'Sem descrição',
      d.category || 'Outros',
      fmt(d.value)
    ]);
    doc.autoTable({
      startY: yPos,
      head: [['Data', 'Descrição', 'Categoria', 'Valor']],
      body: dailyBody,
      theme: 'grid',
      headStyles: { fillColor: [245, 158, 11], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 0: { cellWidth: 25 }, 1: { cellWidth: 65 }, 2: { cellWidth: 35 }, 3: { halign: 'right', cellWidth: 35 } },
      margin: { left: 14, right: 14 }
    });
    yPos = doc.lastAutoTable.finalY + 12;
  }

  // Seção de Metas
  if (data.goals.length > 0) {
    if (yPos > pageHeight - 40) { doc.addPage(); yPos = 15; }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(15, 23, 42);
    doc.text('7. METAS DE ECONOMIA ATIVAS', 14, yPos);
    yPos += 6;

    const goalsBody = data.goals.map(g => [
      `${g.emoji || '🎯'} ${g.name}`,
      fmt(g.current),
      fmt(g.target),
      `${((g.current / (g.target || 1)) * 100).toFixed(0)}%`,
      g.deadline ? new Date(g.deadline + 'T00:00:00').toLocaleDateString('pt-BR') : 'Sem prazo'
    ]);
    doc.autoTable({
      startY: yPos,
      head: [['Objetivo', 'Acumulado', 'Meta', 'Progresso', 'Prazo']],
      body: goalsBody,
      theme: 'grid',
      headStyles: { fillColor: [16, 185, 129], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
      bodyStyles: { textColor: [30, 41, 59], fontSize: 8.5 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
      columnStyles: { 
        0: { cellWidth: 55 }, 
        1: { halign: 'right', cellWidth: 25 }, 
        2: { halign: 'right', cellWidth: 25 }, 
        3: { halign: 'center', cellWidth: 25 }, 
        4: { halign: 'center', cellWidth: 30 } 
      },
      margin: { left: 14, right: 14 }
    });
  }

  // Rodapés com numeração dinâmica
  const totalPages = doc.internal.pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    
    // Linha divisória fina acima do rodapé
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.2);
    doc.line(14, pageHeight - 15, pageWidth - 14, pageHeight - 15);
    
    doc.text('Rover Finance · Inteligência e Controle Financeiro', 14, pageHeight - 10);
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - 14, pageHeight - 10, { align: 'right' });
  }

  const filename = `Rover_Finance_${new Date().toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
  doc.save(filename);
}
