import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { exportFinancialPDF } from '../lib/pdfExporter';
import { Chart as ChartJS, registerables } from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { 
  TrendingUp, 
  TrendingDown, 
  Calendar, 
  CreditCard, 
  DollarSign, 
  Target, 
  Brain, 
  Settings as SettingsIcon, 
  Plus, 
  Trash2, 
  Edit3, 
  LogOut, 
  Search, 
  Download, 
  Send, 
  AlertTriangle, 
  CheckCircle, 
  PlusCircle, 
  Loader2,
  X,
  LayoutDashboard
} from 'lucide-react';

// Registrar componentes do Chart.js
ChartJS.register(...registerables);

// Tipagem dos Dados
interface DailyExpense {
  id: string;
  description: string;
  value: number;
  date: string;
  category: string;
  user_id?: string;
}

interface FixedExpense {
  id: string;
  name: string;
  value: number;
  category: string;
  user_id?: string;
}

interface Installment {
  id: string;
  name: string;
  value: number;
  total: number;
  paid: number;
  category: string;
  user_id?: string;
}

interface MonthlyIncome {
  id: string;
  source: string;
  value: number;
  user_id?: string;
}

interface Goal {
  id: string;
  name: string;
  target: number;
  current: number;
  emoji: string;
  deadline: string;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

const PANEL_ORDER = ['dashboard', 'daily', 'fixed', 'installments', 'income', 'goals', 'ai', 'settings'] as const;
type PanelType = typeof PANEL_ORDER[number];

export default function Home() {
  // Estados de Sessão e Carregamento
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  
  // Inputs de Autenticação
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setPasswordConfirm] = useState('');
  const [fullName, setFullName] = useState('');

  // Dados Financeiros
  const [daily, setDaily] = useState<DailyExpense[]>([]);
  const [fixed, setFixed] = useState<FixedExpense[]>([]);
  const [inst, setInst] = useState<Installment[]>([]);
  const [income, setIncome] = useState<MonthlyIncome[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);

  // Filtros e Buscas
  const [activePanel, setActivePanel] = useState<PanelType>('dashboard');
  const [dailyFilter, setDailyFilter] = useState<'month' | 'today' | '7days' | '30days'>('month');
  const [dailySearch, setDailySearch] = useState('');
  const [dashboardPeriod, setDashboardPeriod] = useState<'month' | '3months' | 'year'>('month');
  const [customCategoriesHistory, setCustomCategoryHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('rv_custom_categories');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Formulários de Entrada
  const [formDaily, setFormDaily] = useState({ description: '', value: '', date: '', category: 'Alimentação', customCategory: '' });
  const [formFixed, setFormFixed] = useState({ name: '', value: '', category: 'Moradia', customCategory: '' });
  const [formInst, setFormInst] = useState({ name: '', value: '', total: '', paid: '0', category: 'Cartão', customCategory: '' });
  const [formIncome, setFormIncome] = useState({ source: '', value: '' });
  const [formGoal, setFormGoal] = useState({ name: '', target: '', current: '', emoji: '🎯', deadline: '' });

  // Estados dos Modais Customizados
  const [modalEdit, setModalEdit] = useState<{ open: boolean; item: any; type: 'daily' | 'fixed' | 'installment' | 'income' | null }>({ open: false, item: null, type: null });
  const [modalDeleteConfirm, setModalDeleteConfirm] = useState<{ open: boolean; itemToDelete: { id: string; table: string; label: string } | null }>({ open: false, itemToDelete: null });
  const [modalGoalContrib, setModalGoalContrib] = useState<{ open: boolean; goalId: string | null; value: string }>({ open: false, goalId: null, value: '' });
  const [modalDeleteAccount, setModalDeleteAccount] = useState(false);
  const [deleteAccountConfirmText, setDeleteAccountConfirmText] = useState('');

  // Estados de Edição de Itens
  const [editName, setEditName] = useState('');
  const [editValue, setEditValue] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editCustomCategory, setEditCustomCategory] = useState('');
  const [editPaid, setEditPaid] = useState('');
  const [editTotal, setEditTotal] = useState('');

  // Chat com IA
  const [aiInput, setAiInput] = useState('');
  const [aiHistory, setAiHistory] = useState<Message[]>([]);
  const [aiLoading, setAiLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Toasts de Notificação
  const [toast, setToast] = useState<{ show: boolean; msg: string; type: 'success' | 'error' | 'info' }>({ show: false, msg: '', type: 'info' });

  // Refs de navegação e scroll
  const panelsContainerRef = useRef<HTMLDivElement>(null);
  const menuNavRef = useRef<HTMLDivElement>(null);
  const isScrollingRef = useRef(false);

  // Constantes do App
  const CATS = ['Alimentação', 'Moradia', 'Transporte', 'Lazer', 'Saúde', 'Educação', 'Cartão', 'Outros'];
  const COLORS: { [key: string]: string } = { 
    'Alimentação': '#EF4444', 
    'Moradia': '#3B82F6', 
    'Transporte': '#F59E0B', 
    'Lazer': '#8B5CF6', 
    'Saúde': '#10B981', 
    'Educação': '#EC4899', 
    'Cartão': '#64748B', 
    'Outros': '#94A3B8' 
  };

  // Mostrar Toast temporário
  const showToast = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ show: true, msg, type });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
  };

  // Formatar Moeda Brasileira
  const fmt = (v: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);

  // Mascarar entrada para formato monetário
  const handleCurrencyMask = (val: string) => {
    const clean = val.replace(/\D/g, '');
    if (!clean) return '';
    return (parseInt(clean, 10) / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // Converter valor monetário formatado para número puro
  const parseV = (v: string) => {
    return Number(String(v).replace(/\D/g, '')) / 100;
  };

  // Monitorar Estado de Autenticação do Usuário
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Carregar todos os dados ao autenticar
  useEffect(() => {
    if (user) {
      loadAllData();
    }
  }, [user]);

  // Rolar chat para o final
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiHistory, aiLoading]);

  // Sincronizar o scroll horizontal do container com a aba ativa
  useEffect(() => {
    if (panelsContainerRef.current && !isScrollingRef.current) {
      const container = panelsContainerRef.current;
      const index = PANEL_ORDER.indexOf(activePanel);
      if (index !== -1) {
        const targetScrollLeft = index * container.clientWidth;
        container.scrollTo({
          left: targetScrollLeft,
          behavior: 'smooth'
        });
      }
    }

    // Centralizar o botão ativo no menu inferior rolável
    if (menuNavRef.current) {
      const activeBtn = menuNavRef.current.querySelector(`[data-tab="${activePanel}"]`);
      if (activeBtn) {
        activeBtn.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'center'
        });
      }
    }
  }, [activePanel]);

  // Listener de Scroll para detectar mudança de aba por swipe com trava (Scroll Snapping)
  const handleContainerScroll = () => {
    if (!panelsContainerRef.current) return;
    
    const container = panelsContainerRef.current;
    const scrollLeft = container.scrollLeft;
    const width = container.clientWidth;
    
    if (width === 0) return;

    // Usar um temporizador para atualizar o painel ativo apenas quando o scroll assentar (estabilizar)
    clearTimeout((window as any)._scrollSnapTimeout);
    (window as any)._scrollSnapTimeout = setTimeout(() => {
      const index = Math.round(scrollLeft / width);
      const targetPanel = PANEL_ORDER[index];
      
      if (targetPanel && targetPanel !== activePanel) {
        isScrollingRef.current = true;
        setActivePanel(targetPanel);
        
        // Liberar a flag de scroll programático logo em seguida
        setTimeout(() => {
          isScrollingRef.current = false;
        }, 50);
      }
    }, 100);
  };

  // Carregar dados do banco de dados
  const loadAllData = async () => {
    try {
      const u = user || (await supabase.auth.getUser()).data.user;
      if (!u) return;

      const [resDaily, resFixed, resInst, resIncome] = await Promise.all([
        supabase.from('daily_expenses').select('*').eq('user_id', u.id),
        supabase.from('fixed_expenses').select('*').eq('user_id', u.id),
        supabase.from('installments').select('*').eq('user_id', u.id),
        supabase.from('monthly_incomes').select('*').eq('user_id', u.id)
      ]);

      setDaily(resDaily.data || []);
      setFixed(resFixed.data || []);
      setInst(resInst.data || []);
      setIncome(resIncome.data || []);

      // Carregar Metas do localStorage (vinculado ao ID do usuário)
      const storedGoals = localStorage.getItem(`rvGoals_${u.id}`);
      setGoals(storedGoals ? JSON.parse(storedGoals) : []);
    } catch (err) {
      console.error(err);
      showToast('Erro ao sincronizar dados', 'error');
    }
  };

  // Lógica de Autenticação (Login / Cadastro)
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return showToast('Preencha todos os campos obrigatórios', 'error');

    if (authMode === 'register') {
      if (!fullName) return showToast('Preencha seu nome completo', 'error');
      if (password !== confirmPassword) return showToast('As senhas não conferem', 'error');
      if (password.length < 6) return showToast('A senha deve ter no mínimo 6 caracteres', 'error');

      setLoading(true);
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { full_name: fullName } }
      });

      setLoading(false);
      if (error) {
        showToast(`Erro: ${error.message}`, 'error');
      } else {
        showToast('Conta criada! Verifique seu email para confirmar.', 'success');
        setAuthMode('login');
      }
    } else {
      setLoading(true);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) {
        showToast('Email ou senha incorretos', 'error');
      } else {
        showToast('Bem-vindo de volta!', 'success');
      }
    }
  };

  // Logout do Usuário
  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setAiHistory([]);
    showToast('Sessão encerrada', 'info');
  };

  // Cálculos Financeiros Consolidados
  const totalIncome = income.reduce((a, x) => a + Number(x.value || 0), 0);
  const totalFixed = fixed.reduce((a, x) => a + Number(x.value || 0), 0);
  const totalDaily = daily.reduce((a, x) => a + Number(x.value || 0), 0);
  const totalInstallments = inst.filter(x => Number(x.paid) < Number(x.total)).reduce((a, x) => a + Number(x.value || 0), 0);
  
  const totalExpenses = totalFixed + totalDaily + totalInstallments;
  const balance = totalIncome - totalExpenses;
  
  // Dívida restante futura nos parcelamentos
  const totalDebt = inst.reduce((a, x) => {
    const remaining = Math.max(Number(x.total || 0) - Number(x.paid || 0), 0);
    return a + (Number(x.value || 0) * remaining);
  }, 0);

  const progressPct = totalIncome > 0 ? Math.min(100, (balance / totalIncome) * 100) : 0;

  // Salvar nova categoria customizada no histórico local para sugestões rápidas
  const saveCustomCategoryToHistory = (cat: string) => {
    if (!cat || !cat.trim()) return;
    const cleanCat = cat.trim();
    if (CATS.includes(cleanCat)) return;
    
    setCustomCategoryHistory(prev => {
      if (prev.includes(cleanCat)) return prev;
      const updated = [cleanCat, ...prev].slice(0, 15); // Limitar a 15 sugestões
      localStorage.setItem('rv_custom_categories', JSON.stringify(updated));
      return updated;
    });
  };

  // Lógica de Adicionar Itens com Validação Aprimorada e Categorias Customizadas
  const handleAddDaily = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseV(formDaily.value);
    if (!formDaily.description.trim()) return showToast('Descrição é obrigatória', 'error');
    if (val <= 0) return showToast('Valor deve ser maior que zero', 'error');
    
    let categoryToSave = formDaily.category;
    if (categoryToSave === 'Outros' && formDaily.customCategory.trim()) {
      categoryToSave = formDaily.customCategory.trim();
      saveCustomCategoryToHistory(categoryToSave);
    }

    const dateToSave = formDaily.date || new Date().toISOString().split('T')[0];

    const { error } = await supabase.from('daily_expenses').insert([{
      description: formDaily.description.trim(),
      value: val,
      date: dateToSave,
      category: categoryToSave,
      user_id: user.id
    }]);

    if (error) {
      showToast('Erro ao salvar no banco', 'error');
    } else {
      setFormDaily({ description: '', value: '', date: '', category: 'Alimentação', customCategory: '' });
      await loadAllData();
      showToast('Gasto registrado com sucesso!', 'success');
    }
  };

  const handleAddFixed = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseV(formFixed.value);
    if (!formFixed.name.trim()) return showToast('Descrição é obrigatória', 'error');
    if (val <= 0) return showToast('Valor deve ser maior que zero', 'error');

    let categoryToSave = formFixed.category;
    if (categoryToSave === 'Outros' && formFixed.customCategory.trim()) {
      categoryToSave = formFixed.customCategory.trim();
      saveCustomCategoryToHistory(categoryToSave);
    }

    const { error } = await supabase.from('fixed_expenses').insert([{
      name: formFixed.name.trim(),
      value: val,
      category: categoryToSave,
      user_id: user.id
    }]);

    if (error) {
      showToast('Erro ao salvar no banco', 'error');
    } else {
      setFormFixed({ name: '', value: '', category: 'Moradia', customCategory: '' });
      await loadAllData();
      showToast('Despesa fixa registrada!', 'success');
    }
  };

  const handleAddInst = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseV(formInst.value);
    const total = parseInt(formInst.total, 10);
    const paid = parseInt(formInst.paid, 10) || 0;

    if (!formInst.name.trim()) return showToast('Nome do parcelamento é obrigatório', 'error');
    if (val <= 0) return showToast('Valor da parcela deve ser maior que zero', 'error');
    if (isNaN(total) || total <= 0) return showToast('Número total de parcelas inválido', 'error');
    if (paid < 0 || paid > total) return showToast('Parcelas pagas devem ser entre 0 e o total', 'error');

    let categoryToSave = formInst.category;
    if (categoryToSave === 'Outros' && formInst.customCategory.trim()) {
      categoryToSave = formInst.customCategory.trim();
      saveCustomCategoryToHistory(categoryToSave);
    }

    const { error } = await supabase.from('installments').insert([{
      name: formInst.name.trim(),
      value: val,
      total,
      paid,
      category: categoryToSave,
      user_id: user.id
    }]);

    if (error) {
      showToast('Erro ao salvar no banco', 'error');
    } else {
      setFormInst({ name: '', value: '', total: '', paid: '0', category: 'Cartão', customCategory: '' });
      await loadAllData();
      showToast('Parcelamento adicionado com sucesso!', 'success');
    }
  };

  const handleAddIncome = async (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseV(formIncome.value);
    if (!formIncome.source.trim()) return showToast('Fonte de receita é obrigatória', 'error');
    if (val <= 0) return showToast('Valor deve ser maior que zero', 'error');

    const { error } = await supabase.from('monthly_incomes').insert([{
      source: formIncome.source.trim(),
      value: val,
      user_id: user.id
    }]);

    if (error) {
      showToast('Erro ao salvar no banco', 'error');
    } else {
      setFormIncome({ source: '', value: '' });
      await loadAllData();
      showToast('Receita adicionada!', 'success');
    }
  };

  // Lógica de Metas no LocalStorage (sem alterar Supabase)
  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const target = parseV(formGoal.target);
    const current = parseV(formGoal.current) || 0;

    if (!formGoal.name.trim()) return showToast('Nome do objetivo é obrigatório', 'error');
    if (target <= 0) return showToast('Meta financeira deve ser maior que zero', 'error');
    if (current < 0) return showToast('Valor acumulado não pode ser negativo', 'error');

    const newGoal: Goal = {
      id: Date.now().toString(),
      name: formGoal.name.trim(),
      target,
      current,
      emoji: formGoal.emoji || '🎯',
      deadline: formGoal.deadline
    };

    const updatedGoals = [...goals, newGoal];
    setGoals(updatedGoals);
    localStorage.setItem(`rvGoals_${user.id}`, JSON.stringify(updatedGoals));
    
    setFormGoal({ name: '', target: '', current: '', emoji: '🎯', deadline: '' });
    showToast('Meta de economia criada!', 'success');
  };

  const handleDelGoal = (id: string) => {
    const updatedGoals = goals.filter(g => g.id !== id);
    setGoals(updatedGoals);
    localStorage.setItem(`rvGoals_${user.id}`, JSON.stringify(updatedGoals));
    showToast('Meta excluída', 'info');
  };

  const handleGoalContrib = () => {
    const contribVal = parseV(modalGoalContrib.value);
    if (contribVal <= 0) return showToast('Insira um valor maior que zero', 'error');
    if (!modalGoalContrib.goalId) return;

    const updatedGoals = goals.map(g => {
      if (g.id === modalGoalContrib.goalId) {
        const newCurrent = (g.current || 0) + contribVal;
        return { ...g, current: newCurrent };
      }
      return g;
    });

    setGoals(updatedGoals);
    localStorage.setItem(`rvGoals_${user.id}`, JSON.stringify(updatedGoals));
    setModalGoalContrib({ open: false, goalId: null, value: '' });
    showToast('Contribuição registrada!', 'success');
  };

  // Lógica de Incremento de Parcela Única (+1)
  const handlePlus1 = async (item: Installment) => {
    if (item.paid >= item.total) return;
    const { error } = await supabase
      .from('installments')
      .update({ paid: Number(item.paid) + 1 })
      .eq('id', item.id);

    if (error) {
      showToast('Erro ao atualizar parcelamento', 'error');
    } else {
      await loadAllData();
      showToast(`Parcela ${item.paid + 1}/${item.total} de "${item.name}" paga!`, 'success');
    }
  };

  // Modais de Edição e Exclusão Customizados (Substitutos de confirm/prompt)
  const handleOpenEdit = (item: any, type: 'daily' | 'fixed' | 'installment' | 'income') => {
    setModalEdit({ open: true, item, type });
    setEditName(item.name || item.description || item.source || '');
    setEditValue(fmt(item.value));
    
    const isStandardCat = CATS.includes(item.category);
    setEditCategory(isStandardCat ? item.category : 'Outros');
    setEditCustomCategory(isStandardCat ? '' : item.category || '');
    
    setEditPaid(String(item.paid || ''));
    setEditTotal(String(item.total || ''));
  };

  const handleSaveEdit = async () => {
    const val = parseV(editValue);
    if (!editName.trim()) return showToast('Nome/Descrição é obrigatório', 'error');
    if (val <= 0) return showToast('Valor deve ser maior que zero', 'error');

    let table = '';
    let payload: any = {};

    let categoryToSave = editCategory;
    if (categoryToSave === 'Outros' && editCustomCategory.trim()) {
      categoryToSave = editCustomCategory.trim();
    }

    if (modalEdit.type === 'daily') {
      table = 'daily_expenses';
      payload = { description: editName.trim(), value: val, category: categoryToSave };
    } else if (modalEdit.type === 'fixed') {
      table = 'fixed_expenses';
      payload = { name: editName.trim(), value: val, category: categoryToSave };
    } else if (modalEdit.type === 'installment') {
      const total = parseInt(editTotal, 10);
      const paid = parseInt(editPaid, 10);
      if (isNaN(total) || total <= 0) return showToast('Total de parcelas inválido', 'error');
      if (paid < 0 || paid > total) return showToast('Parcelas pagas inválidas', 'error');
      
      table = 'installments';
      payload = { name: editName.trim(), value: val, category: categoryToSave, total, paid };
    } else if (modalEdit.type === 'income') {
      table = 'monthly_incomes';
      payload = { source: editName.trim(), value: val };
    }

    const { error } = await supabase.from(table).update(payload).eq('id', modalEdit.item.id);

    if (error) {
      showToast('Erro ao salvar alterações', 'error');
    } else {
      setModalEdit({ open: false, item: null, type: null });
      await loadAllData();
      showToast('Alterações salvas com sucesso!', 'success');
    }
  };

  const handleOpenDeleteConfirm = (id: string, table: string, label: string) => {
    setModalDeleteConfirm({ open: true, itemToDelete: { id, table, label } });
  };

  const handleDeleteItem = async () => {
    if (!modalDeleteConfirm.itemToDelete) return;
    const { id, table } = modalDeleteConfirm.itemToDelete;

    const { error } = await supabase.from(table).delete().eq('id', id);

    if (error) {
      showToast('Erro ao excluir item', 'error');
    } else {
      setModalDeleteConfirm({ open: false, itemToDelete: null });
      await loadAllData();
      showToast('Item excluído', 'info');
    }
  };

  // Excluir todos os dados da conta (Simulado, sem apagar usuário Supabase)
  const handleDeleteAccountData = async () => {
    if (deleteAccountConfirmText !== 'CONFIRMAR') return;
    try {
      const tables = ['daily_expenses', 'fixed_expenses', 'installments', 'monthly_incomes'];
      for (const t of tables) {
        await supabase.from(t).delete().eq('user_id', user.id);
      }
      localStorage.removeItem(`rvGoals_${user.id}`);
      showToast('Todos os seus dados financeiros foram limpos!', 'success');
      setModalDeleteAccount(false);
      handleLogout();
    } catch (err) {
      showToast('Erro ao limpar dados', 'error');
    }
  };

  // Chat com IA Inteligente e Protegido
  const handleSendAI = async () => {
    const text = aiInput.trim();
    if (!text) return;

    setAiInput('');
    setAiHistory(prev => [...prev, { role: 'user', text }]);
    setAiLoading(true);

    const context = {
      user: user?.user_metadata?.full_name || 'Rover',
      resumo: { 
        receita: fmt(totalIncome), 
        despesa_mensal: fmt(totalExpenses), 
        saldo: fmt(balance), 
        divida_total: fmt(totalDebt) 
      },
      detalhes: { 
        receitas: income, 
        fixas: fixed, 
        parcelas: inst, 
        metas: goals, 
        ultimos_gastos: daily.slice(-10) 
      }
    };

    const systemPrompt = `Você é a ROVER IA, a inteligência financeira do Rover Finance.
    Sua missão é ser um consultor direto, técnico e extremamente eficiente.
    
    DIRETRIZES CRÍTICAS:
    1. Respostas CURTAS, DIRETAS e ACIONÁVEIS. Evite rodeios ou textos excessivamente longos.
    2. NUNCA use asteriscos (*) para negrito ou itálico.
    3. Para destacar valores ou palavras importantes, use APENAS a tag HTML <strong>texto</strong>.
    4. Use emojis de forma moderada e profissional.
    5. Analise os dados fornecidos e responda prontamente à dúvida de forma técnica.
    
    DADOS ATUAIS DO USUÁRIO: ${JSON.stringify(context)}`;

    try {
      const GKEY = "AIzaSyB7Scm-lbKr7EZ1yogwuF_kGMFG4AoUe3Y";
      
      const payload = {
        contents: [
          { role: 'user', parts: [{ text: systemPrompt }] },
          ...aiHistory.map(h => ({
            role: h.role,
            parts: [{ text: h.text }]
          })),
          { role: 'user', parts: [{ text }] }
        ]
      };

      const res = await fetch(`https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GKEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      
      if (json.error) {
        setAiHistory(prev => [...prev, { 
          role: 'model', 
          text: `<strong>Erro na IA:</strong> Não foi possível processar a consulta neste momento.` 
        }]);
      } else {
        const reply = json?.candidates?.[0]?.content?.parts?.[0]?.text || 'Não consegui analisar seus dados financeiros agora. Tente novamente.';
        const sanitizedReply = reply
          .replace(/<script[^>]*>([\s\S]*?)<\/script>/gi, '') 
          .replace(/on\w+="[^"]*"/g, ''); 
        
        setAiHistory(prev => [...prev, { role: 'model', text: sanitizedReply }]);
      }
    } catch (e) {
      setAiHistory(prev => [...prev, { 
        role: 'model', 
        text: 'Erro de conexão com o servidor de IA. Verifique sua rede.' 
      }]);
    } finally {
      setAiLoading(false);
    }
  };

  // Exportar Relatório em PDF Premium
  const handleExportPDF = () => {
    exportFinancialPDF({
      income,
      fixed,
      inst,
      daily,
      goals,
      summary: {
        totalIncome,
        totalExpenses,
        totalFixed,
        totalInstallments,
        totalDaily,
        totalDebt,
        balance
      }
    });
    showToast('Relatório PDF exportado!', 'success');
  };

  // Filtrar lista de gastos à vista
  const getFilteredDaily = () => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    let filtered = [...daily];

    if (dailyFilter === 'today') {
      filtered = filtered.filter(x => new Date(x.date + 'T00:00:00').toDateString() === now.toDateString());
    } else if (dailyFilter === '7days') {
      filtered = filtered.filter(x => {
        const d = new Date(x.date + 'T00:00:00');
        return (now.getTime() - d.getTime()) / 864e5 <= 7;
      });
    } else if (dailyFilter === '30days') {
      filtered = filtered.filter(x => {
        const d = new Date(x.date + 'T00:00:00');
        return (now.getTime() - d.getTime()) / 864e5 <= 30;
      });
    } else if (dailyFilter === 'month') {
      filtered = filtered.filter(x => {
        const d = new Date(x.date + 'T00:00:00');
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      });
    }

    if (dailySearch.trim()) {
      const q = dailySearch.toLowerCase();
      filtered = filtered.filter(x => 
        (x.description || '').toLowerCase().includes(q) || 
        (x.category || '').toLowerCase().includes(q)
      );
    }

    return filtered.sort((a, b) => new Date(b.date + 'T00:00:00').getTime() - new Date(a.date + 'T00:00:00').getTime());
  };

  // Dados de Composição das Despesas por Categoria para os Gráficos com Filtro de Período
  const getCategoryCompositionData = () => {
    const categories: { [key: string]: number } = {};
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    const filterByPeriod = (dateStr: string) => {
      if (!dateStr) return true; // Itens fixos/recorrentes entram por padrão
      const d = new Date(dateStr + 'T00:00:00');
      if (dashboardPeriod === 'month') {
        return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
      } else if (dashboardPeriod === '3months') {
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(now.getMonth() - 3);
        return d >= threeMonthsAgo;
      } else if (dashboardPeriod === 'year') {
        return d.getFullYear() === currentYear;
      }
      return true;
    };

    // Agrupar gastos à vista filtrados por período
    daily.filter(x => filterByPeriod(x.date)).forEach(x => {
      const cat = x.category || 'Outros';
      categories[cat] = (categories[cat] || 0) + Number(x.value || 0);
    });

    // Despesas fixas entram no cálculo (mensal, trimestral ou anualizado)
    fixed.forEach(x => {
      const cat = x.category || 'Outros';
      const multiplier = dashboardPeriod === 'month' ? 1 : dashboardPeriod === '3months' ? 3 : 12;
      categories[cat] = (categories[cat] || 0) + Number(x.value || 0) * multiplier;
    });

    // Parcelamentos ativos entram no cálculo
    inst.forEach(x => {
      const cat = x.category || 'Outros';
      const multiplier = dashboardPeriod === 'month' ? 1 : dashboardPeriod === '3months' ? 3 : 12;
      categories[cat] = (categories[cat] || 0) + Number(x.value || 0) * multiplier;
    });

    const labels = Object.keys(categories);
    const data = Object.values(categories);
    const backgroundColors = labels.map(l => COLORS[l] || '#94A3B8');

    return {
      labels,
      datasets: [{
        data,
        backgroundColor: backgroundColors,
        borderWidth: 0,
        hoverOffset: 4
      }]
    };
  };

  // Dados para o gráfico diário (últimos 30 dias de gastos) com filtro de período
  const getDailyEvolutionData = () => {
    const dailyMap: { [key: string]: number } = {};
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    const filterByPeriod = (dateStr: string) => {
      if (!dateStr) return false;
      const d = new Date(dateStr + 'T00:00:00');
      if (dashboardPeriod === 'month') {
        return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
      } else if (dashboardPeriod === '3months') {
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(now.getMonth() - 3);
        return d >= threeMonthsAgo;
      } else if (dashboardPeriod === 'year') {
        return d.getFullYear() === currentYear;
      }
      return true;
    };

    daily.filter(x => filterByPeriod(x.date)).forEach(d => {
      if (!d.date) return;
      dailyMap[d.date] = (dailyMap[d.date] || 0) + Number(d.value || 0);
    });

    const sortedDates = Object.keys(dailyMap).sort().slice(-10); // Mostrar últimos 10 dias com gastos
    const labels = sortedDates.map(d => {
      const dateParts = d.split('-');
      return `${dateParts[2]}/${dateParts[1]}`; // Formato DD/MM
    });
    const data = sortedDates.map(d => dailyMap[d]);

    return {
      labels,
      datasets: [{
        label: 'Gastos Diários',
        data,
        backgroundColor: '#3B82F6',
        borderRadius: 6,
        borderWidth: 0
      }]
    };
  };

  // Tela de Carregamento Inicial
  if (loading && !user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#1b2347]">
        <Loader2 className="w-10 h-10 text-blue-500 animate-spin mb-4" />
        <p className="text-sm text-slate-300 font-medium">Carregando Rover Finance...</p>
      </div>
    );
  }

  // TELA DE AUTENTICAÇÃO (Fundo mais claro, estilo glassmorphism)
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-[#1e274f]">
        <div className="absolute w-[300px] h-[300px] bg-blue-600/10 rounded-full blur-3xl -top-10 -left-10"></div>
        <div className="absolute w-[300px] h-[300px] bg-purple-600/10 rounded-full blur-3xl -bottom-10 -right-10"></div>

        <div className="glass-panel p-8 w-full max-w-md rounded-2xl relative z-10">
          <div className="mb-8 text-center">
            <p className="text-xs font-bold tracking-[0.3em] text-blue-400 uppercase">ROVER FINANCE</p>
            <h1 className="text-3xl font-extrabold text-white mt-2">Gestão Inteligente</h1>
            <p className="text-xs text-slate-300 mt-2">Sua vida financeira sob controle com IA</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-5">
            {authMode === 'register' && (
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Nome Completo</label>
                <input 
                  type="text" 
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="glass-input w-full px-4 py-3 rounded-xl text-sm mt-1" 
                  placeholder="Seu nome"
                  required
                />
              </div>
            )}

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Email</label>
              <input 
                type="email" 
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="glass-input w-full px-4 py-3 rounded-xl text-sm mt-1" 
                placeholder="seu@email.com"
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Senha</label>
              <input 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="glass-input w-full px-4 py-3 rounded-xl text-sm mt-1" 
                placeholder="Sua senha"
                required
              />
            </div>

            {authMode === 'register' && (
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Confirmar Senha</label>
                <input 
                  type="password" 
                  value={confirmPassword}
                  onChange={e => setPasswordConfirm(e.target.value)}
                  className="glass-input w-full px-4 py-3 rounded-xl text-sm mt-1" 
                  placeholder="Repita a senha"
                  required
                />
              </div>
            )}

            <button 
              type="submit" 
              disabled={loading}
              className="premium-gradient-btn w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                authMode === 'login' ? 'Entrar' : 'Criar Conta'
              )}
            </button>

            <div className="text-center pt-2">
              <button 
                type="button" 
                onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                className="text-xs font-bold text-blue-400 hover:text-blue-300 transition-colors"
              >
                {authMode === 'login' ? 'Criar conta gratuita' : 'Já tenho conta'}
              </button>
            </div>
          </form>
        </div>

        {toast.show && (
          <div className={`fixed bottom-5 left-1/2 -translate-x-1/2 px-4 py-3 rounded-full text-xs font-bold z-50 flex items-center gap-2 shadow-lg transition-all duration-300 ${
            toast.type === 'success' ? 'bg-emerald-500 text-white' : 
            toast.type === 'error' ? 'bg-red-500 text-white' : 'bg-blue-600 text-white'
          }`}>
            {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
            {toast.msg}
          </div>
        )}
      </div>
    );
  }

  // TELA PRINCIPAL DO APP (Fundo muito menos escuro, cabeçalho e menu esfumaçados, scroll travado)
  return (
    <div className="min-h-screen flex flex-col relative pb-24 bg-[#2b3566]">
      {/* Toast Flutuante */}
      {toast.show && (
        <div className={`fixed top-5 left-1/2 -translate-x-1/2 px-4 py-3 rounded-full text-xs font-bold z-50 flex items-center gap-2 shadow-lg transition-all duration-300 ${
          toast.type === 'success' ? 'bg-emerald-500 text-white' : 
          toast.type === 'error' ? 'bg-red-500 text-white' : 'bg-blue-600 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Header Fixo - Vidro Desfocado (Efeito Esfumaçado Real com Dots de Paginação) */}
      <header className="w-full pt-3.5 pb-2.5 px-5 bg-[#2b3566]/50 backdrop-blur-xl border-b border-white/10 flex flex-col gap-2 sticky top-0 z-40 shadow-sm">
        <div className="flex justify-between items-center w-full">
          <div className="flex items-center gap-2">
            <div className="w-6.5 h-6.5 rounded-lg bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center shadow-lg shadow-blue-500/10">
              <span className="font-extrabold text-white text-xs">R</span>
            </div>
            <span className="text-xs font-extrabold text-white/90 tracking-tight">Rover Finance</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button 
              onClick={handleExportPDF}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-all duration-200"
              title="Exportar PDF"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={handleLogout}
              className="p-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-all duration-200"
              title="Sair"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dots de Navegação Mobile */}
        <div className="flex justify-center gap-1 pb-0.5">
          {PANEL_ORDER.map((panel, idx) => (
            <button
              key={panel}
              onClick={() => setActivePanel(panel)}
              className={`h-1 rounded-full transition-all duration-300 ${
                activePanel === panel ? 'w-4 bg-blue-400' : 'w-1 bg-white/20'
              }`}
              title={`Aba ${idx + 1}`}
            />
          ))}
        </div>
      </header>

      {/* Container de Abas com Scroll Horizontal e Travamento de Página (Scroll Snapping rígido) */}
      <div 
        id="panels-container"
        ref={panelsContainerRef}
        onScroll={handleContainerScroll}
        className="flex overflow-x-auto scroll-smooth w-full flex-grow no-scrollbar snap-x snap-mandatory"
        style={{ scrollSnapType: 'x mandatory', WebkitOverflowScrolling: 'touch' }}
      >
        
        {/* 1. DASHBOARD PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Seletor de Período dos Gráficos */}
            <div className="flex justify-end gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
              {[
                { id: 'month', label: 'Mês Atual' },
                { id: '3months', label: '3 Meses' },
                { id: 'year', label: 'Ano Atual' }
              ].map(p => (
                <button
                  key={p.id}
                  onClick={() => setDashboardPeriod(p.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-[9px] font-bold transition-all duration-200 ${
                    dashboardPeriod === p.id 
                      ? 'bg-blue-500 text-white shadow-md' 
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Boas-vindas e Saldo Principal */}
            <div className="glass-panel p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden">
              <div className="absolute w-[200px] h-[200px] bg-blue-500/10 rounded-full blur-2xl -top-10 -left-10 pointer-events-none"></div>
              <div className="relative z-10">
                <p className="text-[10px] font-bold uppercase tracking-wider text-blue-400">RESUMO DA CARTEIRA</p>
                <h2 className="text-xl font-extrabold text-white mt-1">Olá, {user?.user_metadata?.full_name?.split(' ')[0] || 'Rover'}!</h2>
                <p className="text-[10px] text-slate-300 mt-1 flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
                </p>
              </div>
              <div className="text-left md:text-right relative z-10">
                <p className="text-[10px] font-bold text-slate-300 uppercase tracking-wider">Saldo Disponível</p>
                <p className={`text-2xl font-extrabold mt-1 ${balance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {fmt(balance)}
                </p>
              </div>
            </div>

            {/* Barra de Progresso do Saldo */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] text-slate-300 font-semibold px-1">
                <span>Relação Saldo / Receita</span>
                <span>{progressPct.toFixed(0)}%</span>
              </div>
              <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden border border-white/10">
                <div 
                  className={`h-full rounded-full transition-all duration-500 ${balance >= 0 ? 'bg-emerald-500' : 'bg-red-500'}`} 
                  style={{ width: `${Math.max(0, Math.min(100, progressPct))}%` }}
                ></div>
              </div>
            </div>

            {/* Grid de Cartões de Métricas */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">Receitas</span>
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-base font-extrabold text-emerald-400 mt-1">{fmt(totalIncome)}</p>
              </div>

              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">Despesas</span>
                  <TrendingDown className="w-3.5 h-3.5 text-red-400" />
                </div>
                <p className="text-base font-extrabold text-red-400 mt-1">{fmt(totalExpenses)}</p>
              </div>

              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">Fixas</span>
                  <Calendar className="w-3.5 h-3.5 text-blue-400" />
                </div>
                <p className="text-base font-extrabold text-blue-400 mt-1">{fmt(totalFixed)}</p>
              </div>

              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">Parcelas</span>
                  <CreditCard className="w-3.5 h-3.5 text-purple-400" />
                </div>
                <p className="text-base font-extrabold text-purple-400 mt-1">{fmt(totalInstallments)}</p>
              </div>

              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">À Vista</span>
                  <DollarSign className="w-3.5 h-3.5 text-amber-400" />
                </div>
                <p className="text-base font-extrabold text-amber-400 mt-1">{fmt(totalDaily)}</p>
              </div>

              <div className="glass-panel p-3 rounded-xl relative overflow-hidden">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] text-slate-300 uppercase font-bold tracking-wider">Dívida Futura</span>
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                </div>
                <p className="text-base font-extrabold text-rose-400 mt-1">{fmt(totalDebt)}</p>
              </div>
            </div>

            {/* Seção de Gráficos (Chart.js Integrados) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass-panel p-4 rounded-xl">
                <h3 className="font-bold text-white text-xs mb-3">Composição das Despesas</h3>
                <div className="h-48 flex items-center justify-center">
                  {[...daily, ...fixed, ...inst].length === 0 ? (
                    <p className="text-[10px] text-slate-300">Nenhum dado de despesa para exibir.</p>
                  ) : (
                    <Doughnut 
                      data={getCategoryCompositionData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                          legend: {
                            position: 'bottom',
                            labels: { color: '#e2e8f0', boxWidth: 8, font: { size: 9 } }
                          }
                        }
                      }}
                    />
                  )}
                </div>
              </div>

              <div className="glass-panel p-4 rounded-xl">
                <h3 className="font-bold text-white text-xs mb-3">Evolução de Gastos Recentes</h3>
                <div className="h-48 flex items-center justify-center">
                  {daily.length === 0 ? (
                    <p className="text-[10px] text-slate-300">Nenhum gasto à vista registrado recentemente.</p>
                  ) : (
                    <Bar 
                      data={getDailyEvolutionData()} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                          x: { grid: { display: false }, ticks: { color: '#e2e8f0', font: { size: 8 } } },
                          y: { grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#e2e8f0', font: { size: 8 } } }
                        }
                      }}
                    />
                  )}
                </div>
              </div>
            </div>

            {/* Insights Inteligentes */}
            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white text-xs mb-3 flex items-center gap-2">
                <Brain className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
                Insights Financeiros do Rover
              </h3>
              <div className="space-y-2">
                {totalIncome === 0 ? (
                  <p className="text-[10px] text-slate-300">Adicione suas fontes de renda na aba <strong>Receitas</strong> para ativar as análises.</p>
                ) : (
                  <>
                    <div className="p-2.5 bg-white/5 border border-white/10 rounded-lg flex items-start gap-2.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5"></div>
                      <p className="text-[11px] text-slate-300 leading-normal">
                        Seus compromissos fixos e parcelados consomem <strong>{(((totalFixed + totalInstallments) / totalIncome) * 100).toFixed(0)}%</strong> do seu orçamento mensal.
                      </p>
                    </div>
                    {balance < 0 && (
                      <div className="p-2.5 bg-red-500/10 border border-red-500/10 rounded-lg flex items-start gap-2.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5"></div>
                        <p className="text-[11px] text-red-300 leading-normal">
                          Alerta: Suas despesas ultrapassaram suas receitas neste mês. Considere adiar novos gastos supérfluos.
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 2. GASTOS À VISTA PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400">REGISTRO</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Gastos À Vista</h2>
              <p className="text-xs text-slate-300 mt-1">Registre despesas e compras pontuais do dia a dia</p>
            </div>

            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white mb-3 text-xs">Adicionar Novo Gasto</h3>
              <form onSubmit={handleAddDaily} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Descrição</label>
                    <input 
                      type="text" 
                      value={formDaily.description}
                      onChange={e => setFormDaily({ ...formDaily, description: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: Supermercado, Uber, Café"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor</label>
                    <input 
                      type="text" 
                      value={formDaily.value}
                      onChange={e => setFormDaily({ ...formDaily, value: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Data</label>
                    <input 
                      type="date" 
                      value={formDaily.date}
                      onChange={e => setFormDaily({ ...formDaily, date: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Categoria</label>
                    <select 
                      value={formDaily.category}
                      onChange={e => setFormDaily({ ...formDaily, category: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1"
                    >
                      {CATS.map(c => <option key={c} value={c} className="bg-[#171f4c]">{c}</option>)}
                    </select>
                  </div>
                </div>

                {formDaily.category === 'Outros' && (
                  <div className="animate-slide-up space-y-2">
                    <div>
                      <label className="text-[9px] font-bold text-blue-400 uppercase tracking-wider">Nome da Categoria Customizada (Ex: Dívida João)</label>
                      <input 
                        type="text" 
                        value={formDaily.customCategory}
                        onChange={e => setFormDaily({ ...formDaily, customCategory: e.target.value })}
                        className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1 border-blue-500/30" 
                        placeholder="Digite o nome da sua categoria própria"
                        required
                      />
                    </div>
                    {customCategoriesHistory.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="text-[8px] text-slate-400 self-center">Sugestões:</span>
                        {customCategoriesHistory.map(cat => (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => setFormDaily({ ...formDaily, customCategory: cat })}
                            className="px-2 py-0.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 text-[8px] rounded-md border border-blue-500/20"
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <button type="submit" className="premium-gradient-btn w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2">
                  <Plus className="w-3.5 h-3.5" /> REGISTRAR GASTO
                </button>
              </form>
            </div>

            <div className="space-y-3">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1 w-full md:w-auto">
                  {(['month', 'today', '7days', '30days'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setDailyFilter(f)}
                      className={`px-3 py-1.5 rounded-xl text-[10px] font-bold transition-all duration-200 ${
                        dailyFilter === f 
                          ? 'bg-blue-600 text-white shadow-lg' 
                          : 'bg-white/5 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      {f === 'month' ? 'Mês Atual' : f === 'today' ? 'Hoje' : f === '7days' ? '7 Dias' : '30 Dias'}
                    </button>
                  ))}
                </div>

                <div className="relative w-full md:w-48">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text" 
                    value={dailySearch}
                    onChange={e => setDailySearch(e.target.value)}
                    className="glass-input w-full pl-8 pr-3 py-1.5 rounded-xl text-[10px]" 
                    placeholder="Buscar..."
                  />
                </div>
              </div>

              <div className="space-y-2">
                {getFilteredDaily().length === 0 ? (
                  <div className="glass-panel p-6 text-center rounded-xl text-slate-300 text-xs">
                    Nenhum gasto encontrado.
                  </div>
                ) : (
                  getFilteredDaily().map(item => (
                    <div key={item.id} className="glass-panel p-3 rounded-xl flex justify-between items-center glass-panel-hover">
                      <div>
                        <p className="font-bold text-xs text-white">{item.description}</p>
                        <p className="text-[9px] text-slate-300 mt-0.5">
                          {new Date(item.date + 'T00:00:00').toLocaleDateString('pt-BR')} · {item.category}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-red-400 text-xs">−{fmt(item.value)}</span>
                        <button 
                          onClick={() => handleOpenEdit(item, 'daily')}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => handleOpenDeleteConfirm(item.id, 'daily_expenses', item.description)}
                          className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 3. DESPESAS FIXAS PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-blue-400">MENSAL</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Despesas Fixas</h2>
              <p className="text-xs text-slate-300 mt-1">Contas recorrentes que vencem todos os meses</p>
            </div>

            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white mb-3 text-xs">Nova Despesa Fixa</h3>
              <form onSubmit={handleAddFixed} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Descrição</label>
                    <input 
                      type="text" 
                      value={formFixed.name}
                      onChange={e => setFormFixed({ ...formFixed, name: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: Aluguel, Netflix, Internet"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor Mensal</label>
                    <input 
                      type="text" 
                      value={formFixed.value}
                      onChange={e => setFormFixed({ ...formFixed, value: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Categoria</label>
                    <select 
                      value={formFixed.category}
                      onChange={e => setFormFixed({ ...formFixed, category: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1"
                    >
                      {CATS.map(c => <option key={c} value={c} className="bg-[#171f4c]">{c}</option>)}
                    </select>
                  </div>
                </div>

                {formFixed.category === 'Outros' && (
                  <div className="animate-slide-up space-y-2">
                    <div>
                      <label className="text-[9px] font-bold text-blue-400 uppercase tracking-wider">Nome da Categoria Customizada (Ex: Dívida João)</label>
                      <input 
                        type="text" 
                        value={formFixed.customCategory}
                        onChange={e => setFormFixed({ ...formFixed, customCategory: e.target.value })}
                        className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1 border-blue-500/30" 
                        placeholder="Digite o nome da sua categoria própria"
                        required
                      />
                    </div>
                    {customCategoriesHistory.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="text-[8px] text-slate-400 self-center">Sugestões:</span>
                        {customCategoriesHistory.map(cat => (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => setFormFixed({ ...formFixed, customCategory: cat })}
                            className="px-2 py-0.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 text-[8px] rounded-md border border-blue-500/20"
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <button type="submit" className="premium-gradient-btn w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2">
                  <Plus className="w-3.5 h-3.5" /> ADICIONAR DESPESA FIXA
                </button>
              </form>
            </div>

            <div className="space-y-2">
              {fixed.length === 0 ? (
                <div className="glass-panel p-6 text-center rounded-xl text-slate-300 text-xs">
                  Nenhuma despesa fixa cadastrada.
                </div>
              ) : (
                [...fixed].sort((a, b) => (a.name || '').localeCompare(b.name || '')).map(item => (
                  <div key={item.id} className="glass-panel p-3 rounded-xl flex justify-between items-center glass-panel-hover">
                    <div>
                      <p className="font-bold text-xs text-white">{item.name}</p>
                      <p className="text-[9px] text-slate-300 mt-0.5">{item.category}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-red-400 text-xs">−{fmt(item.value)}</span>
                      <button 
                        onClick={() => handleOpenEdit(item, 'fixed')}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        onClick={() => handleOpenDeleteConfirm(item.id, 'fixed_expenses', item.name)}
                        className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* 4. PARCELAMENTOS PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-purple-400">FINANCIAMENTOS</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Parcelamentos</h2>
              <p className="text-xs text-slate-300 mt-1">Compras de longo prazo e parcelas de cartão</p>
            </div>

            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white mb-3 text-xs">Novo Parcelamento</h3>
              <form onSubmit={handleAddInst} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Item / Estabelecimento</label>
                    <input 
                      type="text" 
                      value={formInst.name}
                      onChange={e => setFormInst({ ...formInst, name: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: Notebook, Celular"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor da Parcela</label>
                    <input 
                      type="text" 
                      value={formInst.value}
                      onChange={e => setFormInst({ ...formInst, value: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Parcelas Totais</label>
                    <input 
                      type="number" 
                      value={formInst.total}
                      onChange={e => setFormInst({ ...formInst, total: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: 12"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Parcelas Pagas</label>
                    <input 
                      type="number" 
                      value={formInst.paid}
                      onChange={e => setFormInst({ ...formInst, paid: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: 0"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Categoria</label>
                    <select 
                      value={formInst.category}
                      onChange={e => setFormInst({ ...formInst, category: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1"
                    >
                      {CATS.map(c => <option key={c} value={c} className="bg-[#171f4c]">{c}</option>)}
                    </select>
                  </div>
                </div>

                {formInst.category === 'Outros' && (
                  <div className="animate-slide-up space-y-2">
                    <div>
                      <label className="text-[9px] font-bold text-blue-400 uppercase tracking-wider">Nome da Categoria Customizada (Ex: Dívida João)</label>
                      <input 
                        type="text" 
                        value={formInst.customCategory}
                        onChange={e => setFormInst({ ...formInst, customCategory: e.target.value })}
                        className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1 border-blue-500/30" 
                        placeholder="Digite o nome da sua categoria própria"
                        required
                      />
                    </div>
                    {customCategoriesHistory.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="text-[8px] text-slate-400 self-center">Sugestões:</span>
                        {customCategoriesHistory.map(cat => (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => setFormInst({ ...formInst, customCategory: cat })}
                            className="px-2 py-0.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 text-[8px] rounded-md border border-blue-500/20"
                          >
                            {cat}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <button type="submit" className="premium-gradient-btn w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2">
                  <Plus className="w-3.5 h-3.5" /> ADICIONAR PARCELAMENTO
                </button>
              </form>
            </div>

            <div className="space-y-3">
              {inst.length === 0 ? (
                <div className="glass-panel p-6 text-center rounded-xl text-slate-300 text-xs">
                  Nenhum parcelamento ativo.
                </div>
              ) : (
                [...inst].sort((a, b) => (a.name || '').localeCompare(b.name || '')).map(item => {
                  const pct = Math.min(100, (Number(item.paid || 0) / Number(item.total || 1)) * 100);
                  const isFinished = item.paid >= item.total;
                  return (
                    <div key={item.id} className={`glass-panel p-3.5 rounded-xl space-y-2.5 glass-panel-hover ${isFinished ? 'opacity-50' : ''}`}>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-bold text-xs text-white">{item.name}</p>
                          <p className="text-[9px] text-slate-300 mt-0.5">
                            Parcelas: {item.paid}/{item.total} · {item.category}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white text-xs">{fmt(item.value)}/mês</span>
                          <button 
                            onClick={() => handlePlus1(item)}
                            disabled={isFinished}
                            className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 disabled:opacity-30"
                            title="Marcar paga"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => handleOpenEdit(item, 'installment')}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => handleOpenDeleteConfirm(item.id, 'installments', item.name)}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden border border-white/10">
                          <div className="bg-purple-500 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                        </div>
                        <div className="flex justify-between text-[8px] text-slate-300">
                          <span>{pct.toFixed(0)}% pago</span>
                          <span>Restante: {fmt(item.value * (item.total - item.paid))}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* 5. RECEITAS PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">ENTRADAS</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Receitas</h2>
              <p className="text-xs text-slate-300 mt-1">Fontes de renda e salários recorrentes ou pontuais</p>
            </div>

            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white mb-3 text-xs">Nova Receita</h3>
              <form onSubmit={handleAddIncome} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Fonte / Descrição</label>
                    <input 
                      type="text" 
                      value={formIncome.source}
                      onChange={e => setFormIncome({ ...formIncome, source: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: Salário, Freelance"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor Mensal</label>
                    <input 
                      type="text" 
                      value={formIncome.value}
                      onChange={e => setFormIncome({ ...formIncome, value: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                      required
                    />
                  </div>
                </div>

                <button type="submit" className="premium-gradient-btn w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2">
                  <Plus className="w-3.5 h-3.5" /> ADICIONAR RECEITA
                </button>
              </form>
            </div>

            <div className="space-y-2">
              {income.length === 0 ? (
                <div className="glass-panel p-6 text-center rounded-xl text-slate-300 text-xs">
                  Nenhuma receita cadastrada.
                </div>
              ) : (
                [...income].sort((a, b) => (a.source || '').localeCompare(b.source || '')).map(item => (
                  <div key={item.id} className="glass-panel p-3 rounded-xl flex justify-between items-center glass-panel-hover">
                    <div>
                      <p className="font-bold text-xs text-white">{item.source}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-400 text-xs">+{fmt(item.value)}</span>
                      <button 
                        onClick={() => handleOpenEdit(item, 'income')}
                        className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        onClick={() => handleOpenDeleteConfirm(item.id, 'monthly_incomes', item.source)}
                        className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* 6. METAS PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">OBJETIVOS</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Metas de Economia</h2>
              <p className="text-xs text-slate-300 mt-1">Defina objetivos e acompanhe o acúmulo de patrimônio</p>
            </div>

            <div className="glass-panel p-4 rounded-xl">
              <h3 className="font-bold text-white mb-3 text-xs">Criar Novo Objetivo</h3>
              <form onSubmit={handleAddGoal} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="md:col-span-2">
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Nome da Meta</label>
                    <input 
                      type="text" 
                      value={formGoal.name}
                      onChange={e => setFormGoal({ ...formGoal, name: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="Ex: Viagem, Reserva de Emergência"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Emoji</label>
                    <input 
                      type="text" 
                      value={formGoal.emoji}
                      onChange={e => setFormGoal({ ...formGoal, emoji: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1 text-center" 
                      placeholder="🎯"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor Alvo (Meta)</label>
                    <input 
                      type="text" 
                      value={formGoal.target}
                      onChange={e => setFormGoal({ ...formGoal, target: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Valor Inicial</label>
                    <input 
                      type="text" 
                      value={formGoal.current}
                      onChange={e => setFormGoal({ ...formGoal, current: handleCurrencyMask(e.target.value) })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                      placeholder="R$ 0,00"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Prazo</label>
                    <input 
                      type="date" 
                      value={formGoal.deadline}
                      onChange={e => setFormGoal({ ...formGoal, deadline: e.target.value })}
                      className="glass-input w-full px-3 py-2 rounded-xl text-xs mt-1" 
                    />
                  </div>
                </div>

                <button type="submit" className="premium-gradient-btn w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2">
                  <Plus className="w-3.5 h-3.5" /> CRIAR OBJETIVO
                </button>
              </form>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {goals.length === 0 ? (
                <div className="glass-panel p-6 text-center rounded-xl text-slate-300 text-xs md:col-span-2">
                  Nenhuma meta cadastrada ainda.
                </div>
              ) : (
                goals.map(g => {
                  const pct = Math.min(100, (g.current / g.target) * 100);
                  const isFinished = pct >= 100;
                  return (
                    <div key={g.id} className="glass-panel p-4 rounded-xl space-y-3 flex flex-col justify-between glass-panel-hover">
                      <div className="space-y-2">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl p-1.5 bg-white/5 rounded-lg border border-white/10">{g.emoji}</span>
                            <div>
                              <p className="font-bold text-xs text-white">{g.name}</p>
                              {g.deadline && (
                                <p className="text-[8px] text-slate-300">
                                  Até: {new Date(g.deadline + 'T00:00:00').toLocaleDateString('pt-BR')}
                                </p>
                              )}
                            </div>
                          </div>
                          <button 
                            onClick={() => handleDelGoal(g.id)}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="flex justify-between text-[10px] font-semibold">
                          <span className="text-emerald-400">{fmt(g.current)}</span>
                          <span className="text-slate-300">alvo: {fmt(g.target)}</span>
                        </div>

                        <div className="space-y-1">
                          <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                            <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${pct}%` }}></div>
                          </div>
                          <p className="text-[8px] text-slate-300 text-right">{pct.toFixed(0)}% poupado</p>
                        </div>
                      </div>

                      {isFinished ? (
                        <div className="p-2 bg-emerald-500/10 border border-emerald-500/10 rounded-lg text-center text-[10px] font-bold text-emerald-400">
                          ✅ Objetivo Atingido!
                        </div>
                      ) : (
                        <button 
                          onClick={() => setModalGoalContrib({ open: true, goalId: g.id, value: '' })}
                          className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-[10px] font-bold text-blue-400 border border-white/10 rounded-lg transition-colors"
                        >
                          + Contribuir
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* 7. ROVER IA PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-4 overflow-y-auto h-[calc(100dvh-135px)] flex flex-col">
          <div className="max-w-5xl mx-auto w-full flex flex-col h-full space-y-3">
            <div className="glass-panel p-4 rounded-2xl shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center shadow-lg shadow-blue-500/10">
                  <Brain className="w-4 h-4 text-white animate-pulse" />
                </div>
                <div>
                  <h2 className="text-sm font-extrabold text-white">Rover IA Consultora</h2>
                  <p className="text-[9px] text-slate-300">Tire dúvidas, planeje economias e receba conselhos financeiros reais</p>
                </div>
              </div>
            </div>

            {/* Mensagens de Chat */}
            <div className="glass-panel flex-grow rounded-xl p-3 overflow-y-auto space-y-2 flex flex-col no-scrollbar min-h-[220px]">
              {aiHistory.length === 0 ? (
                <div className="flex-grow flex flex-col items-center justify-center text-center p-4 space-y-3">
                  <Brain className="w-10 h-10 text-slate-500" />
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-white">Como posso te ajudar hoje?</p>
                    <p className="text-[9px] text-slate-300">Consulte sua carteira e tome decisões financeiras mais inteligentes.</p>
                  </div>
                  <div className="grid grid-cols-1 gap-1.5 w-full max-w-sm pt-1">
                    {[
                      'Como está minha saúde financeira atual?',
                      'Onde estou gastando mais este mês?',
                      'Dicas para atingir minhas metas mais rápido'
                    ].map(q => (
                      <button
                        key={q}
                        onClick={() => { setAiInput(q); }}
                        className="px-3 py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded-xl text-left text-[10px] text-slate-300 font-medium"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                aiHistory.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`max-w-[85%] p-3 rounded-2xl text-[11px] leading-relaxed shadow-sm ${
                      msg.role === 'user' 
                        ? 'bg-blue-600 text-white self-end rounded-tr-none' 
                        : 'bg-white/5 border border-white/10 text-slate-200 self-start rounded-tl-none'
                    }`}
                    dangerouslySetInnerHTML={{ __html: msg.text }}
                  />
                ))
              )}

              {aiLoading && (
                <div className="bg-white/5 border border-white/10 text-slate-200 p-3 rounded-2xl rounded-tl-none text-[11px] self-start flex items-center gap-1.5 shrink-0">
                  <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />
                  Analisando seus dados...
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input de Chat (Envia com ENTER habilitado) */}
            <div className="flex gap-2 shrink-0">
              <input 
                type="text" 
                value={aiInput}
                onChange={e => setAiInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendAI();
                  }
                }}
                className="glass-input flex-grow px-3 py-2.5 rounded-xl text-xs" 
                placeholder="Pergunte algo sobre suas finanças..."
                disabled={aiLoading}
              />
              <button 
                onClick={handleSendAI}
                disabled={aiLoading || !aiInput.trim()}
                className="p-2.5 rounded-xl premium-gradient-btn flex items-center justify-center disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* 8. CONFIGURAÇÕES PANEL */}
        <div className="w-full shrink-0 snap-start snap-always p-4 space-y-6 overflow-y-auto h-[calc(100dvh-135px)]">
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="glass-panel p-5 rounded-2xl">
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">PERFIL</p>
              <h2 className="text-xl font-extrabold text-white mt-1">Configurações</h2>
              <p className="text-xs text-slate-300 mt-1">Gerenciamento de conta, segurança e privacidade</p>
            </div>

            <div className="glass-panel p-4 rounded-xl space-y-3">
              <h3 className="font-bold text-white text-xs">Dados de Usuário</h3>
              <div className="space-y-1.5 text-[11px]">
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Nome:</span>
                  <span className="font-bold text-white">{user?.user_metadata?.full_name || 'Rover'}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-slate-400">Email:</span>
                  <span className="font-bold text-white">{user?.email}</span>
                </div>
                <div className="flex justify-between py-1.5">
                  <span className="text-slate-400">Status da Conta:</span>
                  <span className="font-bold text-emerald-400 flex items-center gap-1">
                    <span className="w-1 h-1 rounded-full bg-emerald-400 animate-ping"></span>
                    Ativo (Supabase)
                  </span>
                </div>
              </div>
            </div>

            <div className="glass-panel p-4 rounded-xl border border-red-500/10 space-y-3">
              <h3 className="font-bold text-red-400 text-xs">Zona de Perigo</h3>
              <p className="text-[10px] text-slate-300 leading-normal">
                A exclusão de dados financeiros é permanente. Todos os seus gastos, parcelas, receitas e metas locais serão removidos do banco de dados e do dispositivo.
              </p>
              <button 
                onClick={() => { setModalDeleteAccount(true); setDeleteAccountConfirmText(''); }}
                className="px-3 py-2 bg-red-500/10 border border-red-500/20 hover:bg-red-500/20 text-red-400 font-bold text-[10px] rounded-xl transition-colors"
              >
                LIMPAR TODOS OS DADOS DA CONTA
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Navegação Inferior Fixa - Vidro Desfocado (Efeito Esfumaçado Real com Scroll Horizontal) */}
      <nav className="bg-[#2b3566]/50 backdrop-blur-xl border-t border-white/10 fixed bottom-0 left-0 right-0 z-40 py-2.5 shadow-xl max-w-5xl mx-auto md:rounded-t-2xl">
        <div 
          ref={menuNavRef}
          className="flex overflow-x-auto no-scrollbar scroll-smooth px-4 gap-3 snap-x snap-mandatory"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'daily', label: 'À Vista', icon: DollarSign },
            { id: 'fixed', label: 'Fixas', icon: Calendar },
            { id: 'installments', label: 'Parcelas', icon: CreditCard },
            { id: 'income', label: 'Receitas', icon: TrendingUp },
            { id: 'goals', label: 'Metas', icon: Target },
            { id: 'ai', label: 'IA', icon: Brain },
            { id: 'settings', label: 'Ajustes', icon: SettingsIcon }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activePanel === tab.id;
            return (
              <button
                key={tab.id}
                data-tab={tab.id}
                onClick={() => setActivePanel(tab.id as any)}
                className={`flex items-center gap-2 py-2 px-4 rounded-xl transition-all duration-200 shrink-0 snap-center ${
                  isActive 
                    ? 'text-blue-400 bg-blue-500/15 font-bold scale-105 border border-blue-500/10' 
                    : 'text-slate-300 bg-white/5 hover:bg-white/10'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'stroke-[2.5px]' : 'stroke-[2]'}`} />
                <span className="text-[10px] font-semibold tracking-tight">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ========================================================================= */}
      {/* MODAIS CUSTOMIZADOS */}
      {/* ========================================================================= */}

      {/* 1. MODAL DE EDIÇÃO DE ITENS */}
      {modalEdit.open && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end md:items-center justify-center p-4">
          <div className="glass-panel w-full max-w-md p-6 rounded-2xl space-y-5 animate-slide-up">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-white text-base">Editar Registro</h3>
              <button 
                onClick={() => setModalEdit({ open: false, item: null, type: null })}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Descrição / Nome</label>
                <input 
                  type="text" 
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1" 
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Valor</label>
                <input 
                  type="text" 
                  value={editValue}
                  onChange={e => setEditValue(handleCurrencyMask(e.target.value))}
                  className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1" 
                />
              </div>

              {modalEdit.type !== 'income' && (
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Categoria</label>
                  <select 
                    value={editCategory}
                    onChange={e => setEditCategory(e.target.value)}
                    className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1"
                  >
                    {CATS.map(c => <option key={c} value={c} className="bg-[#171f4c]">{c}</option>)}
                  </select>
                </div>
              )}

              {modalEdit.type !== 'income' && editCategory === 'Outros' && (
                <div className="animate-slide-up">
                  <label className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">Nome da Categoria Customizada</label>
                  <input 
                    type="text" 
                    value={editCustomCategory}
                    onChange={e => setEditCustomCategory(e.target.value)}
                    className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1 border-blue-500/30" 
                    placeholder="Digite sua categoria própria"
                  />
                </div>
              )}

              {modalEdit.type === 'installment' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Pagas</label>
                    <input 
                      type="number" 
                      value={editPaid}
                      onChange={e => setEditPaid(e.target.value)}
                      className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1" 
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total</label>
                    <input 
                      type="number" 
                      value={editTotal}
                      onChange={e => setEditTotal(e.target.value)}
                      className="glass-input w-full px-4 py-2.5 rounded-xl text-sm mt-1" 
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button 
                onClick={() => setModalEdit({ open: false, item: null, type: null })}
                className="flex-1 py-3 rounded-xl font-bold text-xs bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 transition-all duration-200"
              >
                Cancelar
              </button>
              <button 
                onClick={handleSaveEdit}
                className="flex-1 py-3 rounded-xl font-bold text-xs premium-gradient-btn"
              >
                Salvar Alterações
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. MODAL DE CONFIRMAÇÃO DE EXCLUSÃO */}
      {modalDeleteConfirm.open && modalDeleteConfirm.itemToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel w-full max-w-sm p-6 rounded-2xl text-center space-y-4 animate-scale-in">
            <div className="w-12 h-12 bg-red-500/10 border border-red-500/10 rounded-full flex items-center justify-center mx-auto text-red-400">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-white text-base">Confirmar Exclusão</h3>
              <p className="text-xs text-slate-300">
                Tem certeza que deseja excluir "<strong>{modalDeleteConfirm.itemToDelete.label}</strong>"? Esta ação não poderá ser desfeita.
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button 
                onClick={() => setModalDeleteConfirm({ open: false, itemToDelete: null })}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 transition-all duration-200"
              >
                Cancelar
              </button>
              <button 
                onClick={handleDeleteItem}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-red-500 hover:bg-red-600 text-white transition-all duration-200"
              >
                Confirmar Exclusão
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. MODAL DE CONTRIBUIÇÃO DE META */}
      {modalGoalContrib.open && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel w-full max-w-sm p-6 rounded-2xl space-y-4 animate-scale-in">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-white text-sm">Contribuir para Objetivo</h3>
              <button 
                onClick={() => setModalGoalContrib({ open: false, goalId: null, value: '' })}
                className="p-1 rounded-lg hover:bg-white/5 text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Quanto deseja guardar?</label>
              <input 
                type="text" 
                value={modalGoalContrib.value}
                onChange={e => setModalGoalContrib({ ...modalGoalContrib, value: handleCurrencyMask(e.target.value) })}
                className="glass-input w-full px-4 py-3 rounded-xl text-sm mt-1" 
                placeholder="R$ 0,00"
                required
              />
            </div>

            <div className="flex gap-2">
              <button 
                onClick={() => setModalGoalContrib({ open: false, goalId: null, value: '' })}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-white/5 border border-white/10 text-slate-400"
              >
                Cancelar
              </button>
              <button 
                onClick={handleGoalContrib}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs premium-gradient-btn"
              >
                Confirmar Depósito
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. MODAL DE CONFIRMAÇÃO DE EXCLUSÃO DE DADOS DA CONTA */}
      {modalDeleteAccount && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-panel w-full max-w-md p-6 rounded-2xl space-y-5 animate-scale-in">
            <div className="w-12 h-12 bg-red-500/10 border border-red-500/10 rounded-full flex items-center justify-center text-red-400 mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            
            <div className="text-center space-y-2">
              <h3 className="font-bold text-red-400 text-base">Limpar Dados Financeiros</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Esta ação apagará permanentemente todas as suas receitas, despesas, parcelamentos e metas do Rover Finance. Para confirmar, digite <strong className="text-white">CONFIRMAR</strong> abaixo.
              </p>
            </div>

            <input 
              type="text" 
              value={deleteAccountConfirmText}
              onChange={e => setDeleteAccountConfirmText(e.target.value)}
              className="glass-input w-full px-4 py-3 rounded-xl text-center font-bold tracking-widest text-sm" 
              placeholder="DIGITE AQUI"
            />

            <div className="flex gap-2">
              <button 
                onClick={() => setModalDeleteAccount(false)}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-white/5 border border-white/10 text-slate-400"
              >
                Cancelar
              </button>
              <button 
                onClick={handleDeleteAccountData}
                disabled={deleteAccountConfirmText !== 'CONFIRMAR'}
                className="flex-1 py-2.5 rounded-xl font-bold text-xs bg-red-600 hover:bg-red-700 text-white disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-200"
              >
                Limpar Tudo
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
